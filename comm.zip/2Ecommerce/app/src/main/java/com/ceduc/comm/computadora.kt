package com.ceduc.comm

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class computadora : AppCompatActivity() {
    val sharedP = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_computadora)

        val cantidad = findViewById<TextView>(R.id.cantidad2)
        val precio = findViewById<TextView>(R.id.precio2)
        val guardar = findViewById<Button>(R.id.button3)
        val buscar = findViewById<Button>(R.id.Carro2)

        val sp = getSharedPreferences(sharedP, Context.MODE_PRIVATE)

        guardar.setOnClickListener { it: View ->

            val editor = sp.edit()
            editor.putString("CANTIDAD", cantidad.text.toString())
            editor.putString("PRECIO", precio.text.toString())
            editor.apply()

            Toast.makeText(/* context = / MainActivity.this, / text = */
                this, "Datos guardados", /* duration = */
                Toast.LENGTH_LONG
            ).show();
            cantidad.setText("");
            precio.setText("");
        }

        buscar.setOnClickListener {

            val prefsName = sp.getString("Cantidad", "")
            val prefsEmail = sp.getString("Precio", "")

            cantidad.text = prefsName
            precio.text = prefsEmail

            val C = findViewById<Button>(R.id.Carro2)
            C.setOnClickListener {
                val intencion = Intent(this, Carrito::class.java)
                startActivity(intencion)
            }

        }
    }
}