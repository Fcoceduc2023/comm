package com.ceduc.comm

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class drone : AppCompatActivity() {
    val sharedP = " "
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_drone)

        val cantidad = findViewById<TextView>(R.id.cantidad1)
        val precio = findViewById<TextView>(R.id.precio1)
        val guardar = findViewById<Button>(R.id.button)
        val buscar = findViewById<Button>(R.id.Carro1)

        val sp = getSharedPreferences(sharedP, Context.MODE_PRIVATE)

        guardar.setOnClickListener { it: View ->
            // Aqui guardo los valores del formulario en las preferencias
            val editor = sp.edit()
            editor.putString("Cantidad", cantidad.text.toString())
            editor.putString("Precio", precio.text.toString())
            editor.apply()

            Toast.makeText(/* context = / MainActivity.this, / text = */
                this,"Datos guardados",
                Toast.LENGTH_LONG).show();
            cantidad.setText("");
            precio.setText("");

            guardar.setOnClickListener {

                val prefsName = sp.getString("Cantidad", "")
                val prefsEmail = sp.getString("Precio", "")

                cantidad.text = prefsName
                precio.text = prefsEmail

            }


        }


            val D = findViewById<Button>(R.id.Carro1)
        D.setOnClickListener {
            val intencion = Intent(this, Carrito::class.java)
            startActivity(intencion)
        }





    }
}